# Define your function here.
def days_in_feb(user_year):
    days = 28
    if ((user_year % 4) == 0):
        if ((user_year % 100) == 0):
            if ((user_year % 400) == 0):
                days = 29
        else:
            days = 29
    return days

if __name__ == '__main__':
    # Type your code here. Your code must call the function.
    user_input = int(input())
    print(f'{user_input} has {days_in_feb(user_input)} days in February.')